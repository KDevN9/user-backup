#!/bin/bash
# USER TRIAL vmess by 2112354428 Wed 09 Feb 2022 11:58:16 AM +08
exp=$(grep -wE "^### TrialTW0N" "/etc/v2ray/none.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialTW0N 2022-02-11/,/^},{/d" /etc/v2ray/none.json
exp=$(grep -wE "^### TrialTW0N" "/etc/v2ray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialTW0N 2022-02-11/,/^},{/d" /etc/xray/config.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_vmess/TrialTW0N
rm /etc/.maAsiss/info-user-vmess/TrialTW0N
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_vmess/TrialTW0N ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_vmess/TrialTW0N
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialTW0N ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialTW0N
rm -f /etc/.maAsiss/TrialTW0N
rm -f /etc/.maAsiss/TrialTW0N.sh
