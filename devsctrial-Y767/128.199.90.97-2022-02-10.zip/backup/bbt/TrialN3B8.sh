#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 02:54:43 AM +08
exp=$(grep -wE "^#& TrialN3B8" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialN3B8 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^#& TrialN3B8" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialN3B8 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialN3B8
rm /etc/.maAsiss/info-user-grpc/TrialN3B8
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialN3B8 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialN3B8
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialN3B8 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialN3B8
rm -f /etc/.maAsiss/TrialN3B8
rm -f /etc/.maAsiss/TrialN3B8.sh
