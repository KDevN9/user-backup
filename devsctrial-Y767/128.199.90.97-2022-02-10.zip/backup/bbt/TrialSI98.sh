#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 04:02:39 AM +08
exp=$(grep -wE "^#& TrialSI98" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialSI98 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^#& TrialSI98" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialSI98 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialSI98
rm /etc/.maAsiss/info-user-grpc/TrialSI98
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialSI98 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialSI98
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialSI98 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialSI98
rm -f /etc/.maAsiss/TrialSI98
rm -f /etc/.maAsiss/TrialSI98.sh
