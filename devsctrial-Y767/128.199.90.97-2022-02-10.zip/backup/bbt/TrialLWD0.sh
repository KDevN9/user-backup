#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 04:25:21 AM +08
exp=$(grep -wE "^#& TrialLWD0" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialLWD0 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^#& TrialLWD0" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialLWD0 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialLWD0
rm /etc/.maAsiss/info-user-grpc/TrialLWD0
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialLWD0 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialLWD0
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialLWD0 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialLWD0
rm -f /etc/.maAsiss/TrialLWD0
rm -f /etc/.maAsiss/TrialLWD0.sh
