#!/bin/bash
# USER TRIAL TROJAN by 2112354428 Wed 09 Feb 2022 10:30:35 AM +08
exp=$(grep -wE "^#! Trial4373" "/etc/xray/trojan.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#! Trial4373 2022-02-11/,/^},{/d" /etc/xray/trojan.json
systemctl restart x-tr.service > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_trojan/Trial4373
rm /etc/.maAsiss/info-user-trojan/Trial4373
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_trojan/Trial4373 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_trojan/Trial4373
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial4373 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial4373
rm -f /etc/.maAsiss/Trial4373
rm -f /etc/.maAsiss/Trial4373.sh
