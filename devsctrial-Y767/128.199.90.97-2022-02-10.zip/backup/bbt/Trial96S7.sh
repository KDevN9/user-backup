#!/bin/bash
# USER TRIAL SSR by 2112354428 Wed 09 Feb 2022 07:39:50 AM +08
exp=$(grep -wE "^###" "/usr/local/shadowsocksr/akun.conf" | cut -d ' ' -f 3)
sed -i "/^### Trial96S7/d" "/usr/local/shadowsocksr/akun.conf"
cd /usr/local/shadowsocksr
match_del=
cd
rm -f /etc/.maAsiss/db_reseller/2112354428/user_ssr/Trial96S7
rm -f /etc/.maAsiss/info-user-ssr/Trial96S7
/etc/init.d/ssrmu restart
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_ssr/Trial96S7 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_ssr/Trial96S7
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial96S7 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial96S7
rm -f /etc/.maAsiss/Trial96S7
rm -f /etc/.maAsiss/Trial96S7.sh
