#!/bin/bash
# USER TRIAL TRGO by 2112354428 Wed 09 Feb 2022 03:58:09 PM +08
exp=$(grep -E "^### TrialPYYC" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 3)
xid=$(grep -E "^### TrialPYYC" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 4)
echo "$xid" > /etc/trojan-go/tmp
bcod=$(cat /etc/trojan-go/tmp)
sed -i '/'$bcod'/d' /etc/trojan-go/config.json
sed -i "/^### TrialPYYC $exp $xid/d" /etc/trojan-go/akun.conf

rm -f /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialPYYC
rm -f /etc/.maAsiss/info-user-trgo/TrialPYYC
rm -f /etc/trojan-go/tmp
systemctl restart trojan-go > /dev/null 2>&1
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialPYYC ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialPYYC
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialPYYC ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialPYYC
rm -f /etc/.maAsiss/TrialPYYC
rm -f /etc/.maAsiss/TrialPYYC.sh
