#!/bin/bash
# USER TRIAL VMESS by 2112354428 Mon 07 Feb 2022 08:23:15 PM +08
exp=$(grep -wE "^### Trial2TUP" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### Trial2TUP 2022-02-09/,/^},{/d" /etc/xray/config.json
systemctl restart xr-vm-ntls.service > /dev/null 2>&1
systemctl restart xr-vm-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_ray/Trial2TUP
rm /etc/.maAsiss/info-user-v2ray/Trial2TUP
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_ray/Trial2TUP ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_ray/Trial2TUP
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial2TUP ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial2TUP
rm -f /etc/.maAsiss/Trial2TUP
rm -f /etc/.maAsiss/Trial2TUP.sh
