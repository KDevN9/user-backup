#!/bin/bash
# USER TRIAL TRGO by 2112354428 Wed 09 Feb 2022 03:45:35 PM +08
exp=$(grep -E "^### TrialD9I6" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 3)
xid=$(grep -E "^### TrialD9I6" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 4)
echo "$xid" > /etc/trojan-go/tmp
bcod=$(cat /etc/trojan-go/tmp)
sed -i '/'$bcod'/d' /etc/trojan-go/config.json
sed -i "/^### TrialD9I6 $exp $xid/d" /etc/trojan-go/akun.conf

rm -f /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialD9I6
rm -f /etc/.maAsiss/info-user-trgo/TrialD9I6
rm -f /etc/trojan-go/tmp
systemctl restart trojan-go > /dev/null 2>&1
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialD9I6 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_trgo/TrialD9I6
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialD9I6 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialD9I6
rm -f /etc/.maAsiss/TrialD9I6
rm -f /etc/.maAsiss/TrialD9I6.sh
